<script>
    export let href = "";
    export let title = "";
    export let text = "";
</script>

<a target="_blank" rel="noreferrer" {href} {title}>{text}</a>

<style>
    a {
        color: #007bff;
        text-decoration: none;
    }
</style>
